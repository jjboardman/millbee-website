document.querySelector(".btn").addEventListener("click", function () {
  document.querySelector(".date").innerHTML = new Date();
});
